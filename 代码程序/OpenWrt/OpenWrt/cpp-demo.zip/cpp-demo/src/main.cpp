#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    cout << "This is C++ Demo" << endl;
    return 0;
}
