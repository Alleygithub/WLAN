#ifndef TYPEDEF_H
#define TYPEDEF_H

typedef unsigned char byte;
typedef unsigned int word;

#endif // TYPEDEF_H
